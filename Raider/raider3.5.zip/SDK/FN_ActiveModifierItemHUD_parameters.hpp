#pragma once

// Fortnite (3.1) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ActiveModifierItemHUD.ActiveModifierItemHUD_C.AssignIcon
struct UActiveModifierItemHUD_C_AssignIcon_Params
{
	struct FSlateBrush                                 inIconSlateBrush;                                         // (BlueprintVisible, BlueprintReadOnly, Parm)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
